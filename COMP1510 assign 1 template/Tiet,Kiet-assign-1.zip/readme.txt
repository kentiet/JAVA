[TIET, KIET], [A00968665], [A], [February 7th, 2016]

This assignment is [100]% complete.


------------------------
Question one (Stickman) status:

[complete]


------------------------
Question two (SecondsConvert) status:

[complete]


------------------------
Question three (Pack) status:

[complete]


------------------------
Question four (Cylinder) status:

[complete]


------------------------
Question five (BusinessCard) status:

[complete]

