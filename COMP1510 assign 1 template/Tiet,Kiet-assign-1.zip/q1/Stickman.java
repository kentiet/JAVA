package q1;

/**
 * <p>
 * Stick man application is going to draw a picture of human being shape by
 * using the special character.
 * </p>
 *
 * @author TIET, KIET
 * @version 1.0
 */
public class Stickman {
    /**
     * <p>
     * This is the main method that drives the program.
     * </p>
     *
     * @param args command line arguments.
     */
    public static void main(String[] args) {
        // Print out stick man
        System.out.println("         |\"\"\"\"\"\"\"|");
        System.out.println("         | -- -- |");
        System.out.println("         | [o|o] |");
        System.out.println("         | '---' |");
        System.out.println("          \\_____/");
        System.out.println("         ___| |___");
        System.out.println("   _____|   '-'   |_______");
        System.out.println("  |_|_____ .   .   _____|_|");
        System.out.println("        |_|_____|_|");
        System.out.println("         |       |");
        System.out.println("         |  .-.  |");
        System.out.println("         '._| |_.'");
        System.out.println("         /__| |__\\");

        System.out.println();
        System.out.println("Question one was called and ran sucessfully.");
    }

};
